from flask import Flask, request, jsonify
import os
from datetime import datetime

app = Flask(__name__)

# Path to stored message file
DATA_PATH = "/data/message.txt"

# v1 has no /api/health endpoint
# (Students add this in v2)

# v2 TODO:
# - Modify write_message() or update_message() to include a timestamp
#   Format: "<message> (updated at YYYY-MM-DD HH:MM:SS)"
#
# - Add new endpoint /api/health that returns:
#   { "status": "healthy" }


def read_message():
    """
    TODO: 
    - If DATA_PATH exists, read and return the text inside
    - If it doesn't exist, return an empty string
    """
    if os.path.exists(DATA_PATH):
        with open(DATA_PATH, 'r') as f:
            return f.read()
    return ""


def write_message(msg: str):
    """
    TODO:
    - Open DATA_PATH
    - Write msg to the file
    """
    with open(DATA_PATH, 'w') as f:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        f.write(f"{msg} (updated at {timestamp})")


@app.route("/api/message", methods=["GET"])
def get_message():
    """
    TODO:
    - Call read_message()
    - Return { "message": <stored message> } as JSON
    """
    stored_message = read_message()
    return jsonify({"message": stored_message})

@app.route("/api/health", methods=["GET"])
def get_health():
    """
    TODO:
    - Return { "status": "healthy" }
    """
    return jsonify({"status": "healthy"})

@app.route("/api/message", methods=["POST"])
def update_message():
    """
    TODO:
    - Get JSON from request
    - Extract the field "message"
    - Call write_message() to save it
    - Return { "status": "ok" }
    """
    data = request.get_json()
    message = data.get("message", "")
    write_message(message)
    return jsonify({"status": "ok"})





if __name__ == "__main__":
    # Do not change the host or port
    app.run(host="0.0.0.0", port=5001)


